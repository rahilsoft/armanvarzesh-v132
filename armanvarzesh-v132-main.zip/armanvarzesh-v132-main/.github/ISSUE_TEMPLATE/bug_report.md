---
name: Bug report
about: گزارش باگ
title: "[Bug] "
labels: bug
---

**شرح**
**بازتولید**
**انتظار**
**لاگ/اسکرین‌شات**
