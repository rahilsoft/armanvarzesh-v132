---
name: Feature request
about: پیشنهاد قابلیت
title: "[Feature] "
labels: enhancement
---

**مشکل/نیاز**
**پیشنهاد**
**خطر/ریسک**
