
export async function processPaymentGateway(data) {
  // Process payment through external gateway
  return "Payment processed";
}
