## خلاصه
-

## نوع تغییر
- [ ] Feature
- [ ] Fix
- [ ] Chore

## آزمایش‌ها
- [ ] Unit
- [ ] E2E
- [ ] دستی (Smoke)

## چک‌لیست
- [ ] A11y ok
- [ ] i18n ok
- [ ] Security (RBAC/Headers) ok
