import { describe, it, expect } from 'vitest';
describe('booking ui smoke', ()=>{
  it('renders', ()=>{ expect(true).toBe(true); });
});
