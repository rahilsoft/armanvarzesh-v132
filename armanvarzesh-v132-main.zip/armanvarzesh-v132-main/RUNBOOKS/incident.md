# Incident Runbook
- کشف: آلارم، گزارش کاربر، Sentry/OTEL
- تشخیص: /status و لاگ‌ها، recent traces
- مهار: feature flag خاموش، rollout متوقف
- رفع: hotfix یا rollback
- پس‌تحلیل: RCA و اقدام اصلاحی
