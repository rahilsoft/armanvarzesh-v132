# Repo Cleanup Notes
- Folder `_merged_conflicts/` detected. Review and remove after confirming no needed content.
- Ensure `pnpm-workspace.yaml` is at repo root (now duplicated at `armanvarzesh/pnpm-workspace.yaml`).
