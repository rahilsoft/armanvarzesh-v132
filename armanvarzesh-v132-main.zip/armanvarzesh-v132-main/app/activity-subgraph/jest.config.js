const base = require('../../jest.config.base.js');
module.exports = { ...base, rootDir: __dirname, displayName: '@arman/activity-subgraph' };
