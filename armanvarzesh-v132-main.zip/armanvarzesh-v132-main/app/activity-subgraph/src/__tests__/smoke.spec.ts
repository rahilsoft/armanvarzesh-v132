describe('smoke', () => {
  it('true is true', () => {
    expect(true).toBe(true);
  });
});
