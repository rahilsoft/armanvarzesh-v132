
#!/bin/sh
npx prisma migrate deploy
