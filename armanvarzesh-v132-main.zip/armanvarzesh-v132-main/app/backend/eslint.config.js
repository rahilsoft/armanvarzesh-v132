// eslint.config.js - package shim importing root flat config
import base from '../../eslint.config.js';
export default [...base];
