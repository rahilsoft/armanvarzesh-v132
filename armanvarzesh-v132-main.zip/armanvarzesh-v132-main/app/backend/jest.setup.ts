process.env.JWT_SECRET = process.env.JWT_SECRET || 'test_jwt_secret';
process.env.JWT_TTL = process.env.JWT_TTL || '1h';
process.env.REFRESH_JWT_SECRET = process.env.REFRESH_JWT_SECRET || 'test_refresh_secret';
process.env.REFRESH_JWT_TTL = process.env.REFRESH_JWT_TTL || '7d';
