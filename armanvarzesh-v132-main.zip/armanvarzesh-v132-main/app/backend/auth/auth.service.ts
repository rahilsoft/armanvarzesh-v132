// Re-export the real AuthService from the src directory.
// This stub has been replaced to avoid broken imports and point to the actual implementation.
export * from '../src/auth/auth.service';
