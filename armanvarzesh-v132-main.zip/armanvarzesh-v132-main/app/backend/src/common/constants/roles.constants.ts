
export const USER_ROLES = ['user', 'coach', 'admin'];
export const DEFAULT_ROLE = 'user';
