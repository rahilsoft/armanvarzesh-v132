// Minimal sanity test.
describe('sanity', () => {
  it('true is true', () => {
    expect(true).toBe(true);
  });
});
