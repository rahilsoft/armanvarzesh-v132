export default { multipass: true, plugins: ['preset-default','removeXMLNS','removeDimensions'] }
