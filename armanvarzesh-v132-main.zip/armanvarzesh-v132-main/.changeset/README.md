# Changesets
- برای هر تغییر قابل نسخه‌دهی، یک فایل در `.changeset/` بسازید.
- این ریپو فعلاً فقط **version PR** می‌سازد (publish خاموش).