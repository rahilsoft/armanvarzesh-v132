# ADR NNNN: Title

- Status: proposed | accepted | rejected | superseded
- Date: 2025-08-23 (Europe/Amsterdam)

## Context
What is the issue that we're seeing that is motivating this decision?

## Decision
What is the change that we're proposing and/or doing?

## Consequences
What becomes easier or more difficult to do because of this change?
